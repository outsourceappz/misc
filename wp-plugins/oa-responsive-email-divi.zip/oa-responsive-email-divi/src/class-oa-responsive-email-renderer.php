<?php


class OA_Responsive_Email_Renderer
{
    public function make($shortcodes)
    {
        $options = OA_Responsive_Email_Activator::getOptions();

        global $wpdb;
        $output = '';

        if (isset($options['header_activated'])) {
            $header_result = $wpdb->get_results(sprintf('select * from %sposts where ID=%s', $wpdb->prefix, $options['header_activated']), ARRAY_A);
            $output = do_shortcode($header_result[0]['post_content']);
        }

        if (isset($options['footer_activated'])) {
            $footer_result = $wpdb->get_results(sprintf('select * from %sposts where ID=%s', $wpdb->prefix, $options['footer_activated']), ARRAY_A);
            $shortcodes .= '[oa_email_shortcode_grid_section][oa_email_shortcode_grid_row]';
            $shortcodes .= $footer_result[0]['post_content'];
            $shortcodes .= '[/oa_email_shortcode_grid_row][/oa_email_shortcode_grid_section]';
        }

        $shortcodes = '[oa_email_shortcode_grid_main_row]'.$shortcodes.'[/oa_email_shortcode_grid_main_row]';
        $shortcodes = str_replace('et_pb_section', 'oa_email_shortcode_grid_section', $shortcodes);
        $shortcodes = str_replace('et_pb_row', 'oa_email_shortcode_grid_row', $shortcodes);
        $shortcodes = str_replace('et_pb_column', 'oa_email_shortcode_grid_col', $shortcodes);
        $shortcodes = str_replace('et_pb_text', 'oa_email_shortcode_grid_para', $shortcodes);

        $output .= do_shortcode($shortcodes);

        $output .= '</body></html>';

        return $output;
    }
}
