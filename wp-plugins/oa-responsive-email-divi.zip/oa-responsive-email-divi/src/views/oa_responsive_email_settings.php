<div class="wrap">
    <h2>Email Templates</h2>
    <small>A mapping of various email types to templates</small>
</div>